import type { Metadata } from "next";
import localFont from "next/font/local";
import "@/styles/globals.css";

// 1. 템플릿의 배달의민족 폰트 로컬 최적화 설정
// public/fonts 폴더 내에 실제 파일이 있는지 확인해 주세요.
const fontHannaPro = localFont({
  src: "../public/fonts/BMHANNAPro.woff",
  variable: "--font-hanna",
  display: "swap",
});

const fontJua = localFont({
  src: "../public/fonts/BMJUA_ttf.woff",
  variable: "--font-jua",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Dev Portfolio",
  description: "템플릿 기반 리뉴얼 포트폴리오",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="ko"
      // 하이드레이션 에러 방지를 위해 유지합니다.
      suppressHydrationWarning
      // 최적화된 폰트 변수를 html 클래스에 주입합니다.
      className={`${fontHannaPro.variable} ${fontJua.variable}`}
    >
      <body className="font-sans antialiased text-gray-900 dark:text-gray-100">
        {/* 기존의 ThemeProvider와 Navigation을 모두 제거했습니다.
            디자인은 이제 템플릿의 CSS와 page.tsx에 배치될 템플릿 컴포넌트들이 결정합니다.
        */}
        {children}
      </body>
    </html>
  );
}